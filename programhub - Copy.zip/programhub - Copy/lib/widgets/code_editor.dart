import 'package:flutter/material.dart';
import 'package:code_text_field/code_text_field.dart';
import 'package:flutter_highlight/themes/dark.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:highlight/languages/cpp.dart';

class CodeEditor extends StatefulWidget {
  final String initialCode;
  final Function(String) onCodeChanged;
  
  const CodeEditor({
    super.key, 
    this.initialCode = '',
    required this.onCodeChanged,
  });

  @override
  State<CodeEditor> createState() => _CodeEditorState();
}

class _CodeEditorState extends State<CodeEditor> {
  late CodeController _codeController;

  @override
  void initState() {
    super.initState();
    _codeController = CodeController(
      text: widget.initialCode,
      language: cpp,
      params: const EditorParams(
        tabSpaces: 4,
      ),
      modifiers: const [
        IndentModifier(),
      ],
    );
    _codeController.addListener(() {
      widget.onCodeChanged(_codeController.text);
    });
  }

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade800),
      ),
      child: CodeField(
        controller: _codeController,
        textStyle: GoogleFonts.firaCode(
          fontSize: 14,
          color: Colors.white,
        ),
        enabled: true,
        lineNumbers: true,
        expands: false,
        minLines: 10,
        maxLines: null,
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
}
