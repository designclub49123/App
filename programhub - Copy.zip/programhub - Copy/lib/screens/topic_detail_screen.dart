import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'learn_content_screen.dart';

class TopicDetailScreen extends StatelessWidget {
  final int topicNumber;

  const TopicDetailScreen({super.key, required this.topicNumber});

  @override
  Widget build(BuildContext context) {
    String title = _getTopicTitle();
    
    return LearnContentScreen(
      topicNumber: topicNumber,
      topicTitle: title,
    );
  }

  String _getTopicTitle() {
    switch (topicNumber) {
      case 1: return 'Introduction to C++';
      case 2: return 'C++ Syntax & Structure';
      // ...existing cases...
      default: return 'C++ Topic';
    }
  }
}
