import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/dark.dart';

class CodeExamplesScreen extends StatelessWidget {
  const CodeExamplesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Code Examples'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: codeExamples.map((example) => _buildCodeCard(example)).toList(),
      ),
    );
  }

  Widget _buildCodeCard(CodeExample example) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              example.title,
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              example.description,
              style: GoogleFonts.poppins(
                color: Colors.grey,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 16),
            HighlightView(
              example.code,
              language: 'cpp',
              theme: darkTheme,
              padding: const EdgeInsets.all(12),
              textStyle: GoogleFonts.firaCode(
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CodeExample {
  final String title;
  final String description;
  final String code;

  const CodeExample({
    required this.title,
    required this.description,
    required this.code,
  });
}

final List<CodeExample> codeExamples = [
  CodeExample(
    title: 'Hello World',
    description: 'A simple Hello World program in C++',
    code: '''#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}''',
  ),
  CodeExample(
    title: 'Variables',
    description: 'Working with different variable types',
    code: '''#include <iostream>
using namespace std;

int main() {
    int number = 42;
    double pi = 3.14159;
    string text = "C++ Programming";
    
    cout << number << endl;
    cout << pi << endl;
    cout << text << endl;
    return 0;
}''',
  ),
  CodeExample(
    title: 'Functions',
    description: 'Working with functions in C++',
    code: '''#include <iostream>
using namespace std;

int add(int a, int b) {
    return a + b;
}

int main() {
    int result = add(5, 3);
    cout << "Sum: " << result << endl;
    return 0;
}''',
  ),
  CodeExample(
    title: 'Classes',
    description: 'Object-oriented programming basics',
    code: '''#include <iostream>
using namespace std;

class Rectangle {
private:
    int width, height;
public:
    Rectangle(int w, int h) : width(w), height(h) {}
    int area() { return width * height; }
};

int main() {
    Rectangle rect(5, 3);
    cout << "Area: " << rect.area() << endl;
    return 0;
}''',
  ),
];
