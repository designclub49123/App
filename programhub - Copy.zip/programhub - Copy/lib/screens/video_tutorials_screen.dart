import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

class VideoTutorialsScreen extends StatelessWidget {
  const VideoTutorialsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Video Tutorials')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSection('Basics', basicsVideos),
          _buildSection('Object-Oriented Programming', oopVideos),
          _buildSection('Data Structures & Algorithms', dsaVideos),
          _buildSection('Advanced Topics', advancedVideos),
          _buildSection('Projects', projectVideos),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<TutorialVideo> videos) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        ...videos.map((video) => _buildVideoCard(video)),
      ],
    );
  }

  Widget _buildVideoCard(TutorialVideo video) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        title: Text(
          video.title,
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        subtitle: Text(
          video.description,
          style: GoogleFonts.poppins(color: Colors.grey),
        ),
        trailing: const Icon(Icons.play_circle, color: Color(0xFF6F35A5)),
        onTap: () async {
          if (await canLaunchUrl(Uri.parse(video.url))) {
            await launchUrl(Uri.parse(video.url));
          }
        },
      ),
    );
  }
}

class TutorialVideo {
  final String title;
  final String description;
  final String url;

  const TutorialVideo({
    required this.title,
    required this.description,
    required this.url,
  });
}

// Video lists
final List<TutorialVideo> basicsVideos = [
  const TutorialVideo(
    title: 'Introduction to C++',
    description: 'Learn the basics of C++ programming',
    url: 'https://www.youtube.com/watch?v=ZzaPdXTrSb8',
  ),
  const TutorialVideo(
    title: 'Variables and Data Types',
    description: 'Understanding C++ variables and types',
    url: 'https://www.youtube.com/watch?v=6y0bp-mnYU0',
  ),
  const TutorialVideo(
    title: 'Control Flow',
    description: 'Learn about if statements and loops',
    url: 'https://www.youtube.com/watch?v=GQp1zzTwrIg',
  ),
];

final List<TutorialVideo> oopVideos = [
  const TutorialVideo(
    title: 'Classes and Objects',
    description: 'Introduction to OOP concepts',
    url: 'https://www.youtube.com/watch?v=ABRP_5RYhqU',
  ),
  const TutorialVideo(
    title: 'Inheritance and Polymorphism',
    description: 'Advanced OOP concepts',
    url: 'https://www.youtube.com/watch?v=wN0xCwGcDA8',
  ),
];

final List<TutorialVideo> dsaVideos = [
  const TutorialVideo(
    title: 'Arrays and Vectors',
    description: 'Basic data structures in C++',
    url: 'https://www.youtube.com/watch?v=B31LgI4Y4DQ',
  ),
  const TutorialVideo(
    title: 'Linked Lists',
    description: 'Implementation and operations',
    url: 'https://www.youtube.com/watch?v=58YbpRDc4yw',
  ),
];

final List<TutorialVideo> advancedVideos = [
  const TutorialVideo(
    title: 'Templates and STL',
    description: 'Advanced C++ features',
    url: 'https://www.youtube.com/watch?v=2BP8NhxjrO0',
  ),
  const TutorialVideo(
    title: 'Memory Management',
    description: 'Understanding pointers and memory',
    url: 'https://www.youtube.com/watch?v=v7q3y_yEWV4',
  ),
];

final List<TutorialVideo> projectVideos = [
  const TutorialVideo(
    title: 'Calculator Project',
    description: 'Build a calculator in C++',
    url: 'https://www.youtube.com/watch?v=AOQ9HC83uh8',
  ),
  const TutorialVideo(
    title: 'Game Development',
    description: 'Create a simple game in C++',
    url: 'https://www.youtube.com/watch?v=u5BhrA8ED0o',
  ),
];
