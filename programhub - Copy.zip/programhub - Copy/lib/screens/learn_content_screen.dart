import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LearnContentScreen extends StatelessWidget {
  final int topicNumber;
  final String topicTitle;

  const LearnContentScreen({
    super.key, 
    required this.topicNumber,
    required this.topicTitle,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(topicTitle),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _getTopicContent(),
        ),
      ),
    );
  }

  List<Widget> _getTopicContent() {
    switch (topicNumber) {
      case 1:
        return [
          _buildTitle('What is C++?'),
          _buildText('C++ is a general-purpose programming language created by Bjarne Stroustrup as an extension of the C programming language, or "C with Classes".'),
          _buildSubtitle('Key Features:'),
          _buildBulletPoints([
            'Object-Oriented Programming',
            'High Performance',
            'Rich Standard Library',
            'Platform Independent',
            'Low-Level Memory Manipulation'
          ]),
          _buildSubtitle('Applications:'),
          _buildBulletPoints([
            'System Software',
            'Game Development',
            'Desktop Applications',
            'Embedded Systems',
            'High-Performance Computing'
          ]),
        ];
      case 2:
        return [
          _buildTitle('Basic Syntax and Structure'),
          _buildCodeBlock('''
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}'''),
          _buildSubtitle('Program Components:'),
          _buildBulletPoints([
            'Header Files (#include)',
            'Main Function',
            'Namespace Declaration',
            'Statements and Expressions',
            'Comments'
          ]),
        ];
      case 3:
        return [
          _buildTitle('Variables & Data Types'),
          _buildText('C++ supports various data types to store different kinds of values.'),
          _buildSubtitle('Basic Data Types:'),
          _buildBulletPoints([
            'int: Integer numbers (-2147483648 to 2147483647)',
            'float: Single precision floating point numbers',
            'double: Double precision floating point numbers',
            'char: Single characters',
            'bool: Boolean values (true or false)'
          ]),
          _buildCodeBlock('''
// Variable declarations
int age = 25;
float price = 99.99f;
double pi = 3.14159;
char grade = 'A';
bool isValid = true;'''),
        ];
      case 4:
        return [
          _buildTitle('Operators in C++'),
          _buildSubtitle('Arithmetic Operators:'),
          _buildBulletPoints([
            '+ : Addition',
            '- : Subtraction',
            '* : Multiplication',
            '/ : Division',
            '% : Modulus'
          ]),
          _buildCodeBlock('''
int a = 10, b = 3;
int sum = a + b;     // 13
int diff = a - b;    // 7
int prod = a * b;    // 30
int quot = a / b;    // 3
int rem = a % b;     // 1'''),
          _buildSubtitle('Comparison Operators:'),
          _buildBulletPoints([
            '== : Equal to',
            '!= : Not equal to',
            '> : Greater than',
            '< : Less than',
            '>= : Greater than or equal to',
            '<= : Less than or equal to'
          ]),
        ];
      case 5:
        return [
          _buildTitle('Control Flow'),
          _buildSubtitle('If Statement:'),
          _buildCodeBlock('''
if (condition) {
    // code block
} else if (another_condition) {
    // code block
} else {
    // code block
}'''),
          _buildSubtitle('Loops:'),
          _buildCodeBlock('''
// For Loop
for (int i = 0; i < 5; i++) {
    cout << i << endl;
}

// While Loop
int j = 0;
while (j < 5) {
    cout << j << endl;
    j++;
}'''),
        ];
      case 6:
        return [
          _buildTitle('Functions'),
          _buildText('Functions are reusable blocks of code that perform specific tasks.'),
          _buildSubtitle('Function Syntax:'),
          _buildCodeBlock('''
returnType functionName(parameters) {
    // function body
    return value;
}'''),
          _buildSubtitle('Example:'),
          _buildCodeBlock('''
int add(int a, int b) {
    return a + b;
}

int main() {
    int result = add(5, 3);  // returns 8
    return 0;
}'''),
        ];
      case 7:
        return [
          _buildTitle('Arrays'),
          _buildText('Arrays are collections of elements of the same data type stored in contiguous memory locations.'),
          _buildSubtitle('Array Declaration:'),
          _buildCodeBlock('''
// One-dimensional array
int numbers[5] = {1, 2, 3, 4, 5};

// Two-dimensional array
int matrix[2][3] = {
    {1, 2, 3},
    {4, 5, 6}
};'''),
          _buildSubtitle('Array Operations:'),
          _buildBulletPoints([
            'Accessing elements using index',
            'Array traversal',
            'Array modification',
            'Array as function parameters',
            'Dynamic arrays'
          ]),
        ];
      case 8:
        return [
          _buildTitle('Strings'),
          _buildText('Strings in C++ can be handled using C-style strings or the string class from the Standard Template Library.'),
          _buildSubtitle('String Operations:'),
          _buildCodeBlock('''
#include <string>
string str1 = "Hello";
string str2 = "World";

// String concatenation
string result = str1 + " " + str2;

// String length
int length = str1.length();

// Substring
string sub = str1.substr(0, 2);  // "He"'''),
          _buildBulletPoints([
            'String comparison',
            'String modification',
            'Character access',
            'String searching',
            'String transformation'
          ]),
        ];
      case 9:
        return [
          _buildTitle('Pointers'),
          _buildText('Pointers are variables that store memory addresses of other variables.'),
          _buildSubtitle('Pointer Basics:'),
          _buildCodeBlock('''
int x = 10;
int* ptr = &x;  // & gets address of x

cout << *ptr;   // * dereferences ptr to get value
*ptr = 20;      // Modifies x through ptr'''),
          _buildSubtitle('Common Uses:'),
          _buildBulletPoints([
            'Dynamic memory allocation',
            'Array operations',
            'Function parameters',
            'Data structures',
            'Memory management'
          ]),
        ];
      case 10:
        return [
          _buildTitle('Object-Oriented Programming'),
          _buildText('OOP is a programming paradigm based on the concept of objects that contain data and code.'),
          _buildSubtitle('Class Definition:'),
          _buildCodeBlock('''
class Student {
private:
    string name;
    int age;
    
public:
    Student(string n, int a) : name(n), age(a) {}
    
    void display() {
        cout << name << " is " << age << " years old";
    }
};'''),
          _buildSubtitle('OOP Principles:'),
          _buildBulletPoints([
            'Encapsulation: Bundling data and methods',
            'Inheritance: Creating new classes from existing ones',
            'Polymorphism: Multiple forms of a single function',
            'Abstraction: Hiding complex implementation details',
            'Data hiding: Protecting data from direct access'
          ]),
        ];
      default:
        return [
          _buildText('Content coming soon...'),
        ];
    }
  }

  Widget _buildTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 24,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildSubtitle(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildText(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 16,
          color: Colors.grey[300],
        ),
      ),
    );
  }

  Widget _buildBulletPoints(List<String> points) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: points.map((point) => _buildBulletPoint(point)).toList(),
      ),
    );
  }

  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('• ', style: TextStyle(color: Color(0xFF6F35A5), fontSize: 16)),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[300],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCodeBlock(String code) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: Text(
        code,
        style: GoogleFonts.firaCode(
          fontSize: 14,
          color: Colors.grey[300],
        ),
      ),
    );
  }
}
