import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/quiz_question.dart';

class QuizResultPage extends StatelessWidget {
  final List<QuizQuestion> questions;
  final List<int?> selectedAnswers;

  const QuizResultPage({
    super.key,
    required this.questions,
    required this.selectedAnswers,
  });

  String _getFeedback(int score) {
    double percentage = score / questions.length * 100;
    if (percentage >= 90) return 'Excellent!';
    if (percentage >= 70) return 'Good job!';
    if (percentage >= 50) return 'Keep practicing!';
    return 'Need more practice!';
  }

  @override
  Widget build(BuildContext context) {
    int score = 0;
    List<bool> isCorrect = List.filled(questions.length, false);
    
    for (int i = 0; i < questions.length; i++) {
      if (selectedAnswers[i] == questions[i].correctAnswer) {
        score++;
        isCorrect[i] = true;
      }
    }

    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).popUntil((route) => route.isFirst);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Quiz Results'),
          automaticallyImplyLeading: false,
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'Your Score: $score/${questions.length}',
                    style: GoogleFonts.poppins(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _getFeedback(score),
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: questions.length,
                itemBuilder: (context, index) => _buildQuestionResult(
                  index + 1,
                  questions[index],
                  selectedAnswers[index],
                  isCorrect[index],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6F35A5),
                  minimumSize: const Size(double.infinity, 48),
                ),
                child: const Text('Return to Quizzes'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionResult(
    int questionNumber,
    QuizQuestion question,
    int? selectedAnswer,
    bool isCorrect,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      color: isCorrect ? Colors.green.shade900 : Colors.red.shade900,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Question $questionNumber',
              style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(question.question),
            const SizedBox(height: 8),
            Text(
              'Correct Answer: ${question.options[question.correctAnswer]}',
              style: const TextStyle(color: Colors.green),
            ),
            if (selectedAnswer != null && !isCorrect) ...[
              Text(
                'Your Answer: ${question.options[selectedAnswer]}',
                style: const TextStyle(color: Colors.red),
              ),
              if (question.explanation.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  'Explanation: ${question.explanation}',
                  style: const TextStyle(color: Colors.grey),
                ),
              ],
              Text(
                question.incorrectFeedback,
                style: const TextStyle(color: Colors.red),
              ),
            ] else if (isCorrect) ...[
              Text(
                question.correctFeedback,
                style: const TextStyle(color: Colors.green),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
