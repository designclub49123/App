import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../data/quiz_data.dart';
import '../models/quiz_question.dart';
import 'quiz_page.dart';

class QuizScreen extends StatelessWidget {
  const QuizScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('C++ Quizzes'),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: quizSections.length,
        itemBuilder: (context, index) {
          final section = quizSections[index];
          return _buildQuizCard(
            context,
            section.title,
            section.description,
            '${section.questions.length} questions',
            section.questions,
          );
        },
      ),
    );
  }

  Widget _buildQuizCard(BuildContext context, String title, String description, 
      String questions, List<QuizQuestion> quizQuestions) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        title: Text(
          title,
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              description,
              style: GoogleFonts.poppins(color: Colors.grey),
            ),
            Text(
              questions,
              style: GoogleFonts.poppins(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
          ],
        ),
        trailing: ElevatedButton(
          onPressed: () => _startQuiz(context, title, quizQuestions),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF6F35A5),
          ),
          child: const Text('Start'),
        ),
        contentPadding: const EdgeInsets.all(16),
      ),
    );
  }

  void _startQuiz(BuildContext context, String title, List<QuizQuestion> questions) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuizPage(
          title: title,
          questions: questions,
        ),
      ),
    );
  }
}
