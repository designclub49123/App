import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/code_editor.dart';

class ExerciseDetailScreen extends StatefulWidget {
  final String title;
  final String description;
  final String expectedOutput;
  final String starterCode;

  const ExerciseDetailScreen({
    super.key,
    required this.title,
    required this.description,
    required this.expectedOutput,
    required this.starterCode,
  });

  @override
  State<ExerciseDetailScreen> createState() => _ExerciseDetailScreenState();
}

class _ExerciseDetailScreenState extends State<ExerciseDetailScreen> {
  String _currentCode = '';
  bool _isCorrect = false;
  bool _showAnswer = false;

  void _checkAnswer() {
    // TODO: Implement actual code validation
    // This is a placeholder implementation
    setState(() {
      _isCorrect = _currentCode.contains('main()') && 
                   _currentCode.contains(widget.expectedOutput);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isCorrect ? 'Correct!' : 'Try again!'),
        backgroundColor: _isCorrect ? Colors.green : Colors.red,
      ),
    );
  }

  String _getAnswer() {
    // Add answers for each exercise based on title
    switch (widget.title) {
      case 'Hello World':
        return '''#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}''';
      case 'Welcome Program':
        return '''#include <iostream>
using namespace std;

int main() {
    cout << "Welcome to C++ Programming!" << endl;
    return 0;
}''';
      // Add more cases for other exercises
      default:
        return '''// Sample solution will be shown here
#include <iostream>
using namespace std;

int main() {
    // Solution code
    return 0;
}''';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Description Section
                      Text(
                        'Description:',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.description,
                        style: GoogleFonts.poppins(color: Colors.grey),
                      ),
                      const SizedBox(height: 16),
                      
                      // Expected Output Section
                      Text(
                        'Expected Output:',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(12),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A2A2A),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          widget.expectedOutput,
                          style: GoogleFonts.firaCode(color: Colors.grey),
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      // Code Editor Section
                      Text(
                        'Your Code:',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 300,
                        child: CodeEditor(
                          initialCode: widget.starterCode,
                          onCodeChanged: (code) => _currentCode = code,
                        ),
                      ),
                      
                      // Solution Section
                      if (_showAnswer) ...[
                        const SizedBox(height: 16),
                        Text(
                          'Solution:',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(12),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: const Color(0xFF2A2A2A),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            _getAnswer(),
                            style: GoogleFonts.firaCode(
                              color: Colors.grey,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
            
            // Bottom Buttons
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                border: Border(
                  top: BorderSide(color: Colors.grey.shade800),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => setState(() => _showAnswer = !_showAnswer),
                    icon: Icon(_showAnswer ? Icons.visibility_off : Icons.visibility),
                    label: Text(_showAnswer ? 'Hide Solution' : 'Show Solution'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6F35A5),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _checkAnswer,
                    icon: const Icon(Icons.check_circle),
                    label: const Text('Submit'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6F35A5),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
