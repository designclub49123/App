import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

class DocumentationScreen extends StatelessWidget {
  const DocumentationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('C++ Documentation')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildDocSection('Official Documentation', officialDocs),
          _buildDocSection('Online References', onlineRefs),
          _buildDocSection('Community Resources', communityResources),
          _buildDocSection('Learning Paths', learningPaths),
          _buildDocSection('Best Practices', bestPractices),
        ],
      ),
    );
  }

  Widget _buildDocSection(String title, List<Documentation> docs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        ...docs.map((doc) => _buildDocCard(doc)),
      ],
    );
  }

  Widget _buildDocCard(Documentation doc) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        title: Text(
          doc.title,
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        subtitle: Text(
          doc.description,
          style: GoogleFonts.poppins(color: Colors.grey),
        ),
        trailing: const Icon(Icons.launch, color: Color(0xFF6F35A5)),
        onTap: () async {
          if (await canLaunchUrl(Uri.parse(doc.url))) {
            await launchUrl(Uri.parse(doc.url));
          }
        },
      ),
    );
  }
}

class Documentation {
  final String title;
  final String description;
  final String url;

  const Documentation({
    required this.title,
    required this.description,
    required this.url,
  });
}

// Documentation lists
final List<Documentation> officialDocs = [
  const Documentation(
    title: 'C++ Reference',
    description: 'Official C++ language documentation',
    url: 'https://en.cppreference.com/w/',
  ),
  const Documentation(
    title: 'C++ Standard',
    description: 'The C++ ISO Standard documentation',
    url: 'https://isocpp.org/std/the-standard',
  ),
  const Documentation(
    title: 'Microsoft C++ Docs',
    description: 'Microsoft\'s C++ documentation and guides',
    url: 'https://docs.microsoft.com/en-us/cpp/',
  ),
];

final List<Documentation> onlineRefs = [
  const Documentation(
    title: 'LearnCpp.com',
    description: 'Comprehensive C++ tutorials and examples',
    url: 'https://www.learncpp.com/',
  ),
  const Documentation(
    title: 'GeeksforGeeks C++',
    description: 'C++ programming tutorials and examples',
    url: 'https://www.geeksforgeeks.org/cpp-programming-language/',
  ),
];

final List<Documentation> communityResources = [
  const Documentation(
    title: 'Stack Overflow C++',
    description: 'Q&A for C++ programming',
    url: 'https://stackoverflow.com/questions/tagged/c++',
  ),
  const Documentation(
    title: 'Reddit r/cpp',
    description: 'C++ community discussions and news',
    url: 'https://www.reddit.com/r/cpp/',
  ),
];

final List<Documentation> learningPaths = [
  const Documentation(
    title: 'C++ Core Guidelines',
    description: 'Official C++ best practices and guidelines',
    url: 'http://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines',
  ),
  const Documentation(
    title: 'Modern C++ Course',
    description: 'Learn modern C++ programming',
    url: 'https://www.learncpp.com/',
  ),
];

final List<Documentation> bestPractices = [
  const Documentation(
    title: 'Google C++ Style Guide',
    description: 'Google\'s C++ coding standards',
    url: 'https://google.github.io/styleguide/cppguide.html',
  ),
  const Documentation(
    title: 'C++ Best Practices',
    description: 'Collection of C++ best practices',
    url: 'https://github.com/lefticus/cppbestpractices',
  ),
];
