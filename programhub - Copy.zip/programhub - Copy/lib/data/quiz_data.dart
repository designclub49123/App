import '../models/quiz_question.dart';

class QuizSection {
  final String title;
  final String description;
  final List<QuizQuestion> questions;

  const QuizSection({
    required this.title,
    required this.description,
    required this.questions,
  });
}

final List<QuizSection> quizSections = [
  QuizSection(
    title: 'Introduction to C++',
    description: 'Test your basics',
    questions: introQuiz,
  ),
  QuizSection(
    title: 'C++ Syntax & Structure',
    description: 'Test your syntax knowledge',
    questions: syntaxQuiz,
  ),
  // ...existing quiz sections with their respective quiz lists...
];

final List<QuizQuestion> introQuiz = [
  // ...existing quiz questions...
];

final List<QuizQuestion> syntaxQuiz = [
  QuizQuestion(
    question: 'What is the purpose of #include?',
    options: [
      'To add comments',
      'To include header files',
      'To declare variables',
      'To define functions'
    ],
    correctAnswer: 1,
    explanation: '#include is used to include header files in C++',
  ),
  // Add more questions...
];

final List<QuizQuestion> variablesQuiz = [
  // ...existing quiz data...
];

// Continue adding remaining quiz lists...
