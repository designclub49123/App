import 'package:flutter/material.dart';
import 'dart:async';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'C++ Learning',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple, // Changed to violet
        brightness: Brightness.dark, // Changed to dark theme
        scaffoldBackgroundColor: const Color(0xFF1A1A2E), // Dark background
        textTheme: GoogleFonts.poppinsTextTheme(ThemeData.dark().textTheme), // Added Poppins font
        useMaterial3: true,
        cardTheme: const CardTheme(
          color: Color(0xFF16213E), // Dark card color
          elevation: 4,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF16213E), // Dark AppBar
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xFF16213E), // Dark navigation bar
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin { // Added for micro-interactions
  int _selectedIndex = 0;
  late AnimationController _controller; // Added for micro-interactions
  
  final List<Widget> _screens = [
    const LearnScreen(),
    const QuizScreen(),
    const ExerciseScreen(),
    const ResourcesScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController( // Added for micro-interactions
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
  }

  @override
  void dispose() {
    _controller.dispose(); // Added for micro-interactions
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedSwitcher( // Added for micro-interaction
        duration: const Duration(milliseconds: 300),
        child: _screens[_selectedIndex],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          _controller.forward(from: 0); // Added for micro-interaction
          setState(() {
            _selectedIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.school),
            label: 'Learn',
          ),
          NavigationDestination(
            icon: Icon(Icons.quiz),
            label: 'Quiz',
          ),
          NavigationDestination(
            icon: Icon(Icons.code),
            label: 'Practice',
          ),
          NavigationDestination(
            icon: Icon(Icons.library_books),
            label: 'Resources',
          ),
        ],
      ),
    );
  }
}

class LearnScreen extends StatelessWidget {
  const LearnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Learn C++'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionHeader('Getting Started'),
          _buildTopicCard(
            'Introduction to C++',
            'What is C++, features, installation, and your first program',
            Icons.start,
            () => _showTopicContent(context, 1),
          ),
          _buildTopicCard(
            'C++ Syntax & Structure',
            'Basic syntax, directives, namespaces, and I/O',
            Icons.code,
            () => _showTopicContent(context, 2),
          ),
          _buildTopicCard(
            'Variables & Data Types',
            'Data types, variables, constants, and type conversion',
            Icons.data_array,
            () => _showTopicContent(context, 3),
          ),
          _buildSectionHeader('Core Concepts'),
          _buildTopicCard(
            'Operators',
            'Arithmetic, relational, logical, and other operators',
            Icons.calculate,
            () => _showTopicContent(context, 4),
          ),
          _buildTopicCard(
            'Control Flow',
            'Conditions, loops, and control statements',
            Icons.control_camera,
            () => _showTopicContent(context, 5),
          ),
          _buildTopicCard(
            'Functions',
            'Function creation, arguments, and overloading',
            Icons.functions,
            () => _showTopicContent(context, 6),
          ),
          _buildTopicCard(
            'Arrays',
            'One-dimensional and multi-dimensional arrays',
            Icons.grid_on,
            () => _showTopicContent(context, 7),
          ),
          _buildSectionHeader('Advanced Topics'),
          _buildTopicCard(
            'Strings',
            'String handling and manipulation',
            Icons.text_fields,
            () => _showTopicContent(context, 8),
          ),
          _buildTopicCard(
            'Pointers',
            'Memory addresses and pointer operations',
            Icons.arrow_forward,
            () => _showTopicContent(context, 9),
          ),
          _buildTopicCard(
            'Dynamic Memory',
            'Memory allocation and management',
            Icons.memory,
            () => _showTopicContent(context, 10),
          ),
          _buildTopicCard(
            'References',
            'Understanding C++ references',
            Icons.link,
            () => _showTopicContent(context, 11),
          ),
          _buildSectionHeader('Object-Oriented Programming'),
          _buildTopicCard(
            'OOP Basics',
            'Classes, objects, and OOP principles',
            Icons.architecture,
            () => _showTopicContent(context, 12),
          ),
          _buildTopicCard(
            'Constructors & Destructors',
            'Object lifecycle management',
            Icons.build,
            () => _showTopicContent(context, 13),
          ),
          _buildTopicCard(
            'Inheritance',
            'Types of inheritance and access specifiers',
            Icons.account_tree,
            () => _showTopicContent(context, 14),
          ),
          _buildTopicCard(
            'Polymorphism',
            'Function and operator overloading',
            Icons.change_history,
            () => _showTopicContent(context, 15),
          ),
          _buildSectionHeader('Advanced OOP Concepts'),
          _buildTopicCard(
            'Encapsulation & Abstraction',
            'Data hiding, getters, setters, and abstract classes',
            Icons.security,
            () => _showTopicContent(context, 16),
          ),
          
          _buildSectionHeader('Error Handling & File Operations'),
          _buildTopicCard(
            'Exception Handling',
            'try-catch blocks and custom exceptions',
            Icons.warning,
            () => _showTopicContent(context, 17),
          ),
          _buildTopicCard(
            'File Handling',
            'File I/O operations and modes',
            Icons.folder,
            () => _showTopicContent(context, 18),
          ),
          
          _buildSectionHeader('Templates & STL'),
          _buildTopicCard(
            'Templates',
            'Function and class templates',
            Icons.auto_fix_high,
            () => _showTopicContent(context, 19),
          ),
          _buildTopicCard(
            'Standard Template Library',
            'Containers, iterators, and algorithms',
            Icons.library_books,
            () => _showTopicContent(context, 20),
          ),
          
          _buildSectionHeader('Modern C++ Features'),
          _buildTopicCard(
            'Lambda Functions',
            'Lambda expressions and captures',
            Icons.functions,
            () => _showTopicContent(context, 21),
          ),
          _buildTopicCard(
            'Multithreading',
            'Threads and synchronization',
            Icons.timeline,
            () => _showTopicContent(context, 22),
          ),
          _buildTopicCard(
            'Smart Pointers',
            'Memory management with modern pointers',
            Icons.safety_check,
            () => _showTopicContent(context, 23),
          ),
          _buildTopicCard(
            'Networking',
            'Socket programming and data transfer',
            Icons.network_wifi,
            () => _showTopicContent(context, 24),
          ),
          
          _buildSectionHeader('Best Practices & Advanced Topics'),
          _buildTopicCard(
            'C++ Best Practices',
            'Optimization and coding standards',
            Icons.verified,
            () => _showTopicContent(context, 25),
          ),
          _buildTopicCard(
            'Debugging & Error Handling',
            'Debug techniques and common errors',
            Icons.bug_report,
            () => _showTopicContent(context, 26),
          ),
          _buildTopicCard(
            'Advanced C++ Concepts',
            'Function pointers and keywords',
            Icons.psychology,
            () => _showTopicContent(context, 27),
          ),
          
          _buildSectionHeader('Projects'),
          _buildTopicCard(
            'To-Do List Application',
            'File handling and OOP implementation',
            Icons.checklist,
            () => _showTopicContent(context, 28),
          ),
          _buildTopicCard(
            'Banking System',
            'Complete OOP project implementation',
            Icons.account_balance,
            () => _showTopicContent(context, 29),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
          color: Colors.deepPurple, // Changed to violet
        ),
      ),
    );
  }

  Widget _buildTopicCard(String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        leading: Icon(icon, size: 40, color: const Color(0xFF9575CD)), // Violet accent
        title: Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white)), // White text for dark theme
        subtitle: Text(subtitle, style: GoogleFonts.poppins(color: Colors.grey)), // Grey subtitle for contrast
        trailing: const Icon(Icons.arrow_forward_ios, color: Color(0xFF6F35A5)), // Violet arrow
        contentPadding: const EdgeInsets.all(16),
        onTap: onTap,
      ),
    );
  }

  void _showTopicContent(BuildContext context, int topicNumber) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TopicDetailScreen(topicNumber: topicNumber),
      ),
    );
  }
}

class TopicDetailScreen extends StatelessWidget {
  final int topicNumber;

  const TopicDetailScreen({super.key, required this.topicNumber});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_getTopicTitle()),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _getTopicContent(),
        ),
      ),
    );
  }

  String _getTopicTitle() {
    switch (topicNumber) {
      case 1: return 'Introduction to C++';
      case 2: return 'C++ Syntax & Structure';
      case 3: return 'Variables & Data Types';
      case 4: return 'Operators';
      case 5: return 'Control Flow';
      case 6: return 'Functions';
      case 7: return 'Arrays';
      case 8: return 'Strings';
      case 9: return 'Pointers';
      case 10: return 'Dynamic Memory';
      case 11: return 'References';
      case 12: return 'OOP Basics';
      case 13: return 'Constructors & Destructors';
      case 14: return 'Inheritance';
      case 15: return 'Polymorphism';
      case 16: return 'Encapsulation & Abstraction';
      case 17: return 'Exception Handling';
      case 18: return 'File Handling';
      case 19: return 'Templates';
      case 20: return 'Standard Template Library';
      case 21: return 'Lambda Functions';
      case 22: return 'Multithreading';
      case 23: return 'Smart Pointers';
      case 24: return 'Networking';
      case 25: return 'C++ Best Practices';
      case 26: return 'Debugging & Error Handling';
      case 27: return 'Advanced C++ Concepts';
      case 28: return 'Project: To-Do List Application';
      case 29: return 'Project: Banking System';
      default: return 'C++ Topic';
    }
  }

  List<Widget> _getTopicContent() {
    switch (topicNumber) {
      case 1:
        return [
          const Text(
            'What is C++?',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
          ),
          const SizedBox(height: 16),
          const Text(
            'C++ is a general-purpose programming language that was developed as an extension of the C programming language. It supports object-oriented, procedural, and generic programming paradigms.',
            style: TextStyle(fontSize: 16, color: Colors.grey), // Grey for contrast
          ),
          const SizedBox(height: 16),
          const Text(
            'Features of C++:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
          ),
          const SizedBox(height: 8),
          const Padding(
            padding: EdgeInsets.only(left: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('• Object-Oriented Programming', style: TextStyle(color: Colors.grey)), // Grey for contrast
                Text('• High Performance', style: TextStyle(color: Colors.grey)),
                Text('• Rich Standard Library', style: TextStyle(color: Colors.grey)),
                Text('• Platform Independent', style: TextStyle(color: Colors.grey)),
                Text('• Low-Level Memory Manipulation', style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),
        ];
      case 2:
        return [
          const Text(
            'C++ Program Structure',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
          ),
          const SizedBox(height: 16),
          const Text(
            'Basic components of a C++ program:',
            style: TextStyle(fontSize: 18, color: Colors.grey), // Grey for contrast
          ),
          // Add more content for syntax
        ];
      case 16:
        return [
          const Text(
            'Encapsulation & Abstraction',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
          ),
          const SizedBox(height: 16),
          const Text(
            'Access Specifiers:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
          ),
          const SizedBox(height: 8),
          const Padding(
            padding: EdgeInsets.only(left: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('• private: Members only accessible within the class', style: TextStyle(color: Colors.grey)), // Grey for contrast
                Text('• protected: Members accessible in derived classes', style: TextStyle(color: Colors.grey)),
                Text('• public: Members accessible from anywhere', style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          // Add more content for each topic
        ];
      default:
        return [const Text('Content coming soon...', style: TextStyle(color: Colors.grey))]; // Grey for contrast
    }
  }
}

class QuizScreen extends StatelessWidget {
  const QuizScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('C++ Quizzes'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildQuizCard(context, 'Introduction to C++', 'Test your basics', '5 questions', introQuiz),
          _buildQuizCard(context, 'C++ Syntax & Structure', 'Test your syntax knowledge', '5 questions', syntaxQuiz),
          _buildQuizCard(context, 'Variables & Data Types', 'Test your data type knowledge', '10 questions', variablesQuiz),
          _buildQuizCard(context, 'Operators in C++', 'Test your operator skills', '10 questions', operatorsQuiz),
          _buildQuizCard(context, 'Control Flow', 'Test your control flow understanding', '10 questions', controlFlowQuiz),
          _buildQuizCard(context, 'Functions in C++', 'Test your function knowledge', '5 questions', functionsQuiz),
          _buildQuizCard(context, 'Arrays in C++', 'Test your array skills', '10 questions', arraysQuiz),
          _buildQuizCard(context, 'Strings in C++', 'Test your string handling', '5 questions', stringsQuiz),
          _buildQuizCard(context, 'Pointers in C++', 'Test your pointer knowledge', '10 questions', pointersQuiz),
          _buildQuizCard(context, 'Dynamic Memory Allocation', 'Test your memory skills', '5 questions', dynamicMemoryQuiz),
          _buildQuizCard(context, 'References in C++', 'Test your reference knowledge', '5 questions', referencesQuiz),
          _buildQuizCard(context, 'OOP in C++', 'Test your OOP basics', '10 questions', oopQuiz),
          _buildQuizCard(context, 'Constructors & Destructors', 'Test your object lifecycle', '5 questions', constructorsQuiz),
          _buildQuizCard(context, 'Inheritance in C++', 'Test your inheritance skills', '10 questions', inheritanceQuiz),
          _buildQuizCard(context, 'Polymorphism in C++', 'Test your polymorphism knowledge', '10 questions', polymorphismQuiz),
          _buildQuizCard(context, 'Encapsulation & Abstraction', 'Test your OOP concepts', '5 questions', encapsulationQuiz),
          _buildQuizCard(context, 'Exception Handling', 'Test your error handling', '5 questions', exceptionQuiz),
          _buildQuizCard(context, 'File Handling in C++', 'Test your file operations', '10 questions', fileHandlingQuiz),
          _buildQuizCard(context, 'Templates in C++', 'Test your template knowledge', '5 questions', templatesQuiz),
          _buildQuizCard(context, 'Standard Template Library', 'Test your STL skills', '10 questions', stlQuiz),
          _buildQuizCard(context, 'Lambda Functions', 'Test your lambda knowledge', '5 questions', lambdaQuiz),
          _buildQuizCard(context, 'Multithreading in C++', 'Test your threading skills', '5 questions', multithreadingQuiz),
          _buildQuizCard(context, 'Smart Pointers', 'Test your smart pointer usage', '5 questions', smartPointersQuiz),
          _buildQuizCard(context, 'Networking in C++', 'Test your networking basics', '5 questions', networkingQuiz),
          _buildQuizCard(context, 'C++ Best Practices', 'Test your coding standards', '5 questions', bestPracticesQuiz),
          _buildQuizCard(context, 'Debugging & Error Handling', 'Test your debugging skills', '5 questions', debuggingQuiz),
          _buildQuizCard(context, 'Advanced C++ Concepts', 'Test your advanced knowledge', '5 questions', advancedQuiz),
          _buildQuizCard(context, 'To-Do List Application', 'Test your project skills', '5 questions', todoListQuiz),
          _buildQuizCard(context, 'Banking System', 'Test your project implementation', '5 questions', bankingQuiz),
          _buildQuizCard(context, 'Final Quiz & Certification', 'Comprehensive C++ test', '10 questions', finalQuiz),
        ],
      ),
    );
  }

  Widget _buildQuizCard(BuildContext context, String title, String description, 
      String questions, List<QuizQuestion> quizQuestions) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 8),
            Text(description, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(questions, style: const TextStyle(color: Colors.grey)),
                ElevatedButton(
                  onPressed: () => _startQuiz(context, title, quizQuestions),
                  child: const Text('Start Quiz'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _startQuiz(BuildContext context, String title, List<QuizQuestion> questions) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuizPage(title: title, questions: questions),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  final String title;
  final List<QuizQuestion> questions;

  const QuizPage({super.key, required this.title, required this.questions});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late List<int?> selectedAnswers;
  late Timer _timer;
  int _timeLeft = 300; // 5 minutes in seconds

  @override
  void initState() {
    super.initState();
    selectedAnswers = List.filled(widget.questions.length, null);
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_timeLeft > 0) {
          _timeLeft--;
        } else {
          _submitQuiz();
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _submitQuiz() {
    _timer.cancel();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => QuizResultPage(
          questions: widget.questions,
          selectedAnswers: selectedAnswers,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                '${_timeLeft ~/ 60}:${(_timeLeft % 60).toString().padLeft(2, '0')}',
                style: const TextStyle(fontSize: 18, color: Colors.white), // White for dark theme
              ),
            ),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: widget.questions.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Question ${index + 1}',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
                  ),
                  const SizedBox(height: 8),
                  Text(widget.questions[index].question, style: const TextStyle(color: Colors.grey)), // Grey for contrast
                  const SizedBox(height: 16),
                  ...List.generate(
                    widget.questions[index].options.length,
                    (optionIndex) => RadioListTile<int>(
                      title: Text(widget.questions[index].options[optionIndex], style: const TextStyle(color: Colors.grey)), // Grey for contrast
                      value: optionIndex,
                      groupValue: selectedAnswers[index],
                      onChanged: (value) {
                        setState(() {
                          selectedAnswers[index] = value;
                        });
                      },
                      activeColor: const Color(0xFF6F35A5), // Violet for selection
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _submitQuiz,
        label: const Text('Submit Quiz'),
        icon: const Icon(Icons.check),
        backgroundColor: const Color(0xFF6F35A5), // Violet button
      ),
    );
  }
}

class QuizResultPage extends StatelessWidget {
  final List<QuizQuestion> questions;
  final List<int?> selectedAnswers;

  const QuizResultPage({
    super.key, 
    required this.questions, 
    required this.selectedAnswers,
  });

  @override
  Widget build(BuildContext context) {
    int score = 0;
    for (int i = 0; i < questions.length; i++) {
      if (selectedAnswers[i] == questions[i].correctAnswer) {
        score++;
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Quiz Results')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Your Score: $score/${questions.length}',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: questions.length,
              itemBuilder: (context, index) {
                bool isCorrect = selectedAnswers[index] == questions[index].correctAnswer;
                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  color: isCorrect ? Colors.green.shade900 : Colors.red.shade900, // Darker shades for dark theme
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Question ${index + 1}',
                          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white), // White for dark theme
                        ),
                        const SizedBox(height: 8),
                        Text(questions[index].question, style: const TextStyle(color: Colors.grey)), // Grey for contrast
                        const SizedBox(height: 8),
                        Text(
                          'Correct Answer: ${questions[index].options[questions[index].correctAnswer]}',
                          style: const TextStyle(color: Colors.green),
                        ),
                        if (selectedAnswers[index] != null && !isCorrect)
                          Text(
                            'Your Answer: ${questions[index].options[selectedAnswers[index]!]}',
                            style: const TextStyle(color: Colors.red),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Try Another Quiz'),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6F35A5)), // Violet button
            ),
          ),
        ],
      ),
    );
  }
}

class QuizQuestion {
  final String question;
  final List<String> options;
  final int correctAnswer;

  const QuizQuestion({
    required this.question,
    required this.options,
    required this.correctAnswer,
  });
}

final List<QuizQuestion> introQuiz = [
  QuizQuestion(question: 'What is C++?', options: ['A purely functional programming language', 'An object-oriented programming language developed by Bjarne Stroustrup', 'A scripting language', 'A database management system'], correctAnswer: 1),
  QuizQuestion(question: 'Which of the following is NOT a feature of C++?', options: ['Platform independence', 'Manual memory management', 'Object-oriented programming', 'High performance'], correctAnswer: 0),
  QuizQuestion(question: 'What is the purpose of a C++ compiler?', options: ['To execute the program directly', 'To translate C++ code into machine code', 'To debug the program', 'To format the code'], correctAnswer: 1),
  QuizQuestion(question: 'What is the correct syntax to print "Hello, World!" in C++?', options: ['print("Hello, World!")', 'cout << "Hello, World!" << endl;', 'printf("Hello, World!")', 'write("Hello, World!")'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: C++ requires a compiler like GCC or Clang to run programs.', options: ['True', 'False'], correctAnswer: 0),
];

final List<QuizQuestion> syntaxQuiz = [
  QuizQuestion(question: 'What is the purpose of the #include directive?', options: ['To define a function', 'To include external libraries or files', 'To declare variables', 'To end the program'], correctAnswer: 1),
  QuizQuestion(question: 'What is the role of the main() function in a C++ program?', options: ['It serves as the entry point of the program', 'It handles file operations', 'It defines a class', 'It loops the program'], correctAnswer: 0),
  QuizQuestion(question: 'What does cin do in C++?', options: ['Outputs data to the console', 'Takes input from the user', 'Declares a variable', 'Includes a library'], correctAnswer: 1),
  QuizQuestion(question: 'Which of these is a valid single-line comment in C++?', options: ['/* This is a comment */', '# This is a comment', '// This is a comment', '** This is a comment **'], correctAnswer: 2),
  QuizQuestion(question: 'True or False: Every C++ program must include the namespace std; statement.', options: ['True', 'False'], correctAnswer: 1),
];

final List<QuizQuestion> variablesQuiz = [
  QuizQuestion(question: 'How do you declare an integer variable in C++?', options: ['int x = 5;', 'integer x = 5;', 'x = int(5);', 'declare int x = 5;'], correctAnswer: 0),
  QuizQuestion(question: 'Which data type is used to store a single character?', options: ['int', 'float', 'char', 'bool'], correctAnswer: 2),
  QuizQuestion(question: 'What is the output of cout << sizeof(double); on a 64-bit system?', options: ['4', '8', '2', '16'], correctAnswer: 1),
  QuizQuestion(question: 'What does the const keyword do?', options: ['Makes a variable mutable', 'Prevents a variable from being modified', 'Declares a pointer', 'Defines a loop'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: #define PI 3.14 creates a constant that can be changed at runtime.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What is implicit type conversion?', options: ['Manually converting one type to another', 'Automatic conversion by the compiler', 'Using the const keyword', 'Declaring multiple variables'], correctAnswer: 1),
  QuizQuestion(question: 'Which keyword is used for explicit type conversion?', options: ['cast', 'static_cast', 'type', 'convert'], correctAnswer: 1),
  QuizQuestion(question: 'What is the default value of an uninitialized bool variable in C++?', options: ['true', 'false', 'Undefined', '0'], correctAnswer: 2),
  QuizQuestion(question: 'What is the range of an int on a 32-bit system?', options: ['-128 to 127', '-32768 to 32767', '-2147483648 to 2147483647', '0 to 65535'], correctAnswer: 2),
  QuizQuestion(question: 'True or False: A float can store more precise decimal values than a double.', options: ['True', 'False'], correctAnswer: 1),
];

final List<QuizQuestion> operatorsQuiz = [
  QuizQuestion(question: 'What is the result of 5 % 2?', options: ['2', '1', '2.5', '0'], correctAnswer: 1),
  QuizQuestion(question: 'Which operator checks if two values are equal?', options: ['=', '==', '!=', '>='], correctAnswer: 1),
  QuizQuestion(question: 'What does the && operator do?', options: ['Performs a bitwise AND', 'Checks if both conditions are true', 'Assigns a value', 'Shifts bits left'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of cout << (5 > 3 ? 10 : 20);?', options: ['10', '20', '5', '3'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: The >> operator is used for right shifting bits.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the += operator do?', options: ['Adds and assigns the result', 'Compares two values', 'Subtracts and assigns', 'Multiplies two values'], correctAnswer: 0),
  QuizQuestion(question: 'Which operator has the highest precedence?', options: ['+', '*', '==', '&&'], correctAnswer: 1),
  QuizQuestion(question: 'What is the result of 3 & 5 (bitwise AND)?', options: ['1', '3', '5', '7'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: The ternary operator can replace an if-else statement.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the ! operator do?', options: ['Inverts a boolean value', 'Performs a bitwise OR', 'Shifts bits right', 'Multiplies by -1'], correctAnswer: 0),
];

final List<QuizQuestion> controlFlowQuiz = [
  QuizQuestion(question: 'What does the if statement do?', options: ['Loops through code', 'Executes code based on a condition', 'Defines a function', 'Declares a variable'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: int x = 10; if (x > 5) cout << "Yes"; else cout << "No";', options: ['Yes', 'No', 'Nothing', 'Error'], correctAnswer: 0),
  QuizQuestion(question: 'In a switch statement, what keyword ends a case?', options: ['end', 'break', 'continue', 'return'], correctAnswer: 1),
  QuizQuestion(question: 'How many times will this for loop execute: for (int i = 0; i < 5; i++) cout << i;', options: ['4', '5', '6', '0'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: A do-while loop executes at least once even if the condition is false.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the continue keyword do in a loop?', options: ['Exits the loop', 'Skips the current iteration', 'Restarts the loop', 'Pauses the loop'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: int x = 0; while (x < 3) { cout << x; x++; }', options: ['012', '123', '01', '0123'], correctAnswer: 0),
  QuizQuestion(question: 'Which loop is best for iterating a known number of times?', options: ['while', 'do-while', 'for', 'switch'], correctAnswer: 2),
  QuizQuestion(question: 'True or False: A switch statement can use floating-point values.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What does the else-if clause do?', options: ['Executes if the if condition is true', 'Provides an alternative condition to check', 'Loops the program', 'Declares a variable'], correctAnswer: 1),
];

final List<QuizQuestion> functionsQuiz = [
  QuizQuestion(question: 'What is the correct syntax to define a function in C++?', options: ['function add(int a, int b) { return a + b; }', 'int add(int a, int b) { return a + b; }', 'add(int a, int b) -> int { return a + b; }', 'void add(a, b) { return a + b; }'], correctAnswer: 1),
  QuizQuestion(question: 'What is a default argument?', options: ['An argument that is always passed', 'An argument with a predefined value if not provided', 'An argument that cannot be changed', 'An argument passed by reference'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: Function overloading allows multiple functions with the same name but different parameters.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is recursion?', options: ['A function calling another function', 'A function calling itself', 'A function with no return value', 'A function with default arguments'], correctAnswer: 1),
  QuizQuestion(question: 'What does this function return: int square(int x) { return x * x; } square(5);', options: ['5', '10', '25', 'Nothing'], correctAnswer: 2),
];

final List<QuizQuestion> arraysQuiz = [
  QuizQuestion(question: 'How do you declare a one-dimensional array in C++?', options: ['int arr[5];', 'array int[5];', 'int arr(5);', 'int[5] arr;'], correctAnswer: 0),
  QuizQuestion(question: 'What is the index of the first element in an array?', options: ['1', '0', '-1', '2'], correctAnswer: 1),
  QuizQuestion(question: 'What does this code output: int arr[3] = {1, 2, 3}; cout << arr[1];', options: ['1', '2', '3', 'Error'], correctAnswer: 1),
  QuizQuestion(question: 'How do you declare a 2D array?', options: ['int arr[2, 3];', 'int arr[2][3];', 'int arr(2)(3);', 'int[2][3] arr;'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: Arrays in C++ can dynamically resize during runtime.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What is the size of this array in bytes on a 32-bit system: int arr[4];', options: ['4', '8', '16', '12'], correctAnswer: 2),
  QuizQuestion(question: 'What happens if you access an array out of bounds?', options: ['The program crashes immediately', 'Undefined behavior', 'The compiler throws an error', 'It returns 0'], correctAnswer: 1),
  QuizQuestion(question: 'How do you initialize all elements of an array to 0?', options: ['int arr[5] = {0};', 'int arr[5] = 0;', 'int arr[5] = {1, 2, 3, 4, 5};', 'int arr[5] = NULL;'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Multidimensional arrays must have the same size for all dimensions.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What does sizeof(arr) / sizeof(arr[0]) calculate?', options: ['The value of the first element', 'The number of elements in the array', 'The memory address of the array', 'The total size in bytes'], correctAnswer: 1),
];

final List<QuizQuestion> stringsQuiz = [
  QuizQuestion(question: 'What is the key difference between a character array and the string class?', options: ['Character arrays are immutable, strings are mutable', 'string class provides built-in functions, character arrays do not', 'Character arrays use more memory', 'string class cannot store text'], correctAnswer: 1),
  QuizQuestion(question: 'What does the length() function return for the string "Hello"?', options: ['4', '5', '6', '0'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: string s = "C++"; s.append(" Rocks"); cout << s;', options: ['C++', 'C++ Rocks', 'Rocks', 'Error'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: Strings in C++ can be compared using the == operator.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the substr(1, 3) function return for the string "Hello"?', options: ['Hel', 'ell', 'llo', 'lo'], correctAnswer: 1),
];

final List<QuizQuestion> pointersQuiz = [
  QuizQuestion(question: 'What is a pointer in C++?', options: ['A variable that stores a value', 'A variable that stores a memory address', 'A function that returns a value', 'A constant integer'], correctAnswer: 1),
  QuizQuestion(question: 'How do you declare a pointer to an integer?', options: ['int* ptr;', 'int ptr*;', 'pointer int ptr;', 'int &ptr;'], correctAnswer: 0),
  QuizQuestion(question: 'What does the * operator do when used with a pointer?', options: ['Multiplies the pointer value', 'Dereferences the pointer to access the value', 'Assigns a new address', 'Declares a pointer'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: int x = 10; int* ptr = &x; cout << *ptr;', options: ['Memory address of x', '10', 'ptr', 'Error'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: nullptr is used to represent a null pointer in modern C++.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does pointer arithmetic do?', options: ['Adds two pointers together', 'Moves the pointer to the next memory location based on the data type', 'Multiplies pointer values', 'Assigns a new value to the pointer'], correctAnswer: 1),
  QuizQuestion(question: 'What is the value of ptr after ptr++ if it points to an int array?', options: ['Increases by 1', 'Increases by 4 (size of int on most systems)', 'Decreases by 1', 'Stays the same'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: A pointer can point to an array.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the const int* ptr declaration mean?', options: ['The pointer cannot be changed', 'The value it points to cannot be changed', 'Both pointer and value cannot be changed', 'The pointer must be null'], correctAnswer: 1),
  QuizQuestion(question: 'What is the purpose of the & operator?', options: ['Dereferences a pointer', 'Returns the address of a variable', 'Performs a bitwise AND', 'Declares a constant'], correctAnswer: 1),
];

final List<QuizQuestion> dynamicMemoryQuiz = [
  QuizQuestion(question: 'What operator is used to allocate memory dynamically in C++?', options: ['malloc', 'new', 'calloc', 'alloc'], correctAnswer: 1),
  QuizQuestion(question: 'How do you deallocate memory allocated with new?', options: ['delete', 'free', 'clear', 'remove'], correctAnswer: 0),
  QuizQuestion(question: 'What does this code do: int* ptr = new int[5];', options: ['Declares a pointer to a single integer', 'Allocates memory for an array of 5 integers', 'Initializes 5 integers to 0', 'Deletes an array'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: malloc() and calloc() are preferred over new in modern C++.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What happens if you forget to delete dynamically allocated memory?', options: ['The program crashes', 'A memory leak occurs', 'The compiler throws an error', 'Nothing happens'], correctAnswer: 1),
];

final List<QuizQuestion> referencesQuiz = [
  QuizQuestion(question: 'What is a reference in C++?', options: ['A pointer to a variable', 'An alias for an existing variable', 'A constant value', 'A dynamic memory allocation'], correctAnswer: 1),
  QuizQuestion(question: 'How do you declare a reference to an integer?', options: ['int& ref = x;', 'int* ref = x;', 'int ref& = x;', 'ref int = x;'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: A reference must be initialized when declared.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is the output of: int x = 5; int& ref = x; ref = 10; cout << x;', options: ['5', '10', 'Error', 'Memory address'], correctAnswer: 1),
  QuizQuestion(question: 'What is the key difference between a pointer and a reference?', options: ['References cannot be null, pointers can', 'Pointers are immutable, references are not', 'References use more memory', 'Pointers cannot be reassigned'], correctAnswer: 0),
];

final List<QuizQuestion> oopQuiz = [
  QuizQuestion(question: 'What is OOP?', options: ['A programming paradigm based on objects and classes', 'A method for writing loops', 'A type of memory allocation', 'A syntax for file handling'], correctAnswer: 0),
  QuizQuestion(question: 'Which is NOT a principle of OOP?', options: ['Encapsulation', 'Inheritance', 'Polymorphism', 'Recursion'], correctAnswer: 3),
  QuizQuestion(question: 'What is a class in C++?', options: ['A variable type', 'A blueprint for creating objects', 'A function definition', 'A loop structure'], correctAnswer: 1),
  QuizQuestion(question: 'How do you define a simple class in C++?', options: ['class MyClass { public: int x; };', 'struct MyClass { int x; };', 'object MyClass { int x; };', 'MyClass { int x; };'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Objects are instances of classes.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does encapsulation achieve?', options: ['Allows multiple classes to inherit', 'Hides data and restricts access', 'Enables runtime polymorphism', 'Creates abstract classes'], correctAnswer: 1),
  QuizQuestion(question: 'What is inheritance?', options: ['A class reusing properties of another class', 'Overloading a function', 'Creating a pointer', 'Allocating memory'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Polymorphism allows a function to behave differently based on the object calling it.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What keyword is used to create an object of a class?', options: ['new', 'class', 'No keyword, just the class name', 'object'], correctAnswer: 2),
  QuizQuestion(question: 'What does abstraction hide?', options: ['Implementation details', 'Variable names', 'Class definitions', 'Memory addresses'], correctAnswer: 0),
];

final List<QuizQuestion> constructorsQuiz = [
  QuizQuestion(question: 'What is a constructor?', options: ['A function that destroys an object', 'A special member function called when an object is created', 'A loop inside a class', 'A pointer to a class'], correctAnswer: 1),
  QuizQuestion(question: 'What is the name of a default constructor?', options: ['Same as the class name with no parameters', 'default()', 'init()', 'constructor()'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: A destructor is automatically called when an object goes out of scope.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does this code do: class MyClass { public: MyClass() { cout << "Constructor"; } ~MyClass() { cout << "Destructor"; } }; int main() { MyClass obj; return 0; }', options: ['Prints "Constructor" then "Destructor"', 'Prints "Destructor" then "Constructor"', 'Prints only "Constructor"', 'Error'], correctAnswer: 0),
  QuizQuestion(question: 'What is a copy constructor used for?', options: ['Initializing an object with default values', 'Creating a copy of an existing object', 'Deleting an object', 'Overloading a function'], correctAnswer: 1),
];

final List<QuizQuestion> inheritanceQuiz = [
  QuizQuestion(question: 'What is single inheritance?', options: ['A class inheriting from one base class', 'A class inheriting from multiple base classes', 'A class with no inheritance', 'A class inheriting from itself'], correctAnswer: 0),
  QuizQuestion(question: 'How do you specify inheritance in C++?', options: ['class Derived : public Base { };', 'class Derived inherits Base { };', 'class Derived extends Base { };', 'class Derived < Base { };'], correctAnswer: 0),
  QuizQuestion(question: 'What does the protected access specifier allow?', options: ['Access only within the class', 'Access within the class and derived classes', 'Public access to all', 'No access at all'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: class Base { public: int x = 5; }; class Derived : public Base { }; int main() { Derived d; cout << d.x; return 0; }', options: ['5', '0', 'Error', 'Undefined'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Multiple inheritance allows a class to inherit from more than one base class.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is multilevel inheritance?', options: ['A chain of inheritance (e.g., A → B → C)', 'Multiple classes inheriting from one base', 'A class inheriting from itself', 'No inheritance at all'], correctAnswer: 0),
  QuizQuestion(question: 'What does private inheritance mean?', options: ['Base class members become private in the derived class', 'Base class members are inaccessible', 'Base class members remain public', 'Derived class cannot inherit'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Hybrid inheritance combines multiple types of inheritance.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is the diamond problem?', options: ['A syntax error in C++', 'Ambiguity in multiple inheritance', 'A memory leak', 'A type conversion issue'], correctAnswer: 1),
  QuizQuestion(question: 'How can the diamond problem be resolved?', options: ['Using virtual inheritance', 'Avoiding inheritance', 'Using pointers', 'Deleting the base class'], correctAnswer: 0),
];

final List<QuizQuestion> polymorphismQuiz = [
  QuizQuestion(question: 'What is polymorphism?', options: ['Ability of a function to have multiple forms', 'Ability to inherit from multiple classes', 'Ability to allocate memory dynamically', 'Ability to hide data'], correctAnswer: 0),
  QuizQuestion(question: 'What is function overloading?', options: ['Defining multiple functions with the same name but different parameters', 'Calling a function recursively', 'Overriding a base class function', 'Deleting a function'], correctAnswer: 0),
  QuizQuestion(question: 'What does operator overloading allow?', options: ['Redefining how operators work with user-defined types', 'Overriding built-in operators', 'Deleting operators', 'Using operators with pointers'], correctAnswer: 0),
  QuizQuestion(question: 'What is the output of: class Base { public: virtual void show() { cout << "Base"; } }; class Derived : public Base { public: void show() { cout << "Derived"; } }; int main() { Base* ptr = new Derived(); ptr->show(); delete ptr; return 0; }', options: ['Base', 'Derived', 'Error', 'Nothing'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: Method overriding requires the virtual keyword in the base class.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is a pure virtual function?', options: ['A function with no implementation', 'A function declared as virtual void func() = 0;', 'A function that must be overridden', 'All of the above'], correctAnswer: 3),
  QuizQuestion(question: 'What is an abstract class?', options: ['A class with at least one pure virtual function', 'A class with no functions', 'A class that cannot be inherited', 'A class with private members'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: You can create an object of an abstract class.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What does the virtual keyword ensure?', options: ['Compile-time polymorphism', 'Runtime polymorphism', 'Memory allocation', 'Data hiding'], correctAnswer: 1),
  QuizQuestion(question: 'What is the purpose of operator overloading?', options: ['To improve performance', 'To make code more intuitive for user-defined types', 'To reduce memory usage', 'To prevent inheritance'], correctAnswer: 1),
];

final List<QuizQuestion> encapsulationQuiz = [
  QuizQuestion(question: 'What is encapsulation?', options: ['Hiding implementation details and restricting access to data', 'Inheriting from multiple classes', 'Overloading functions', 'Creating virtual functions'], correctAnswer: 0),
  QuizQuestion(question: 'What are getters and setters used for?', options: ['To access and modify private data members', 'To delete objects', 'To override operators', 'To allocate memory'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: private members can be accessed directly outside the class.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What does abstraction focus on?', options: ['Exposing only essential details and hiding complexity', 'Inheriting from a base class', 'Overloading operators', 'Managing memory'], correctAnswer: 0),
  QuizQuestion(question: 'What is the output of: class MyClass { private: int x = 5; public: int getX() { return x; } }; int main() { MyClass obj; cout << obj.getX(); return 0; }', options: ['5', '0', 'Error', 'x'], correctAnswer: 0),
];

final List<QuizQuestion> exceptionQuiz = [
  QuizQuestion(question: 'What keyword is used to throw an exception?', options: ['catch', 'throw', 'try', 'error'], correctAnswer: 1),
  QuizQuestion(question: 'What does the try block contain?', options: ['Code that might throw an exception', 'Code that catches an exception', 'Code that throws an exception explicitly', 'Code that terminates the program'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Multiple catch blocks can handle different types of exceptions.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is the output of: try { throw 10; } catch (int e) { cout << "Caught " << e; }', options: ['Caught 10', 'Error', '10', 'Nothing'], correctAnswer: 0),
  QuizQuestion(question: 'What happens if an exception is not caught?', options: ['The program continues running', 'The program terminates abnormally', 'The compiler throws an error', 'The exception is ignored'], correctAnswer: 1),
];

final List<QuizQuestion> fileHandlingQuiz = [
  QuizQuestion(question: 'Which header is required for file handling in C++?', options: ['<iostream>', '<fstream>', '<string>', '<vector>'], correctAnswer: 1),
  QuizQuestion(question: 'What is the purpose of ofstream?', options: ['Reading from a file', 'Writing to a file', 'Appending to a file', 'Deleting a file'], correctAnswer: 1),
  QuizQuestion(question: 'What does ios::app mode do?', options: ['Overwrites the file', 'Appends data to the end of the file', 'Reads from the file', 'Creates a new file'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: #include <fstream> int main() { ofstream file("test.txt"); file << "Hello"; file.close(); return 0; }', options: ['Prints "Hello" to the console', 'Writes "Hello" to test.txt', 'Reads "Hello" from test.txt', 'Error'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: You must close a file after using it.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does ifstream do?', options: ['Writes to a file', 'Reads from a file', 'Appends to a file', 'Deletes a file'], correctAnswer: 1),
  QuizQuestion(question: 'How do you check if a file opened successfully?', options: ['file.is_open()', 'file.open()', 'file.check()', 'file.good()'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: fstream can be used for both reading and writing.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does this code do: ifstream file("data.txt"); string line; while (getline(file, line)) { cout << line; }', options: ['Writes lines to data.txt', 'Reads and prints lines from data.txt', 'Deletes data.txt', 'Appends to data.txt'], correctAnswer: 1),
  QuizQuestion(question: 'What happens if you try to open a non-existent file with ifstream?', options: ['A new file is created', 'The operation fails', 'The program crashes', 'It overwrites the file'], correctAnswer: 1),
];

final List<QuizQuestion> templatesQuiz = [
  QuizQuestion(question: 'What is a template in C++?', options: ['A way to write generic code', 'A type of loop', 'A memory allocation technique', 'A file handling method'], correctAnswer: 0),
  QuizQuestion(question: 'How do you define a function template?', options: ['template <typename T> void func(T x) { }', 'function <T> void func(T x) { }', 'void func(template T x) { }', 'template void func(T x) { }'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Templates allow code to work with multiple data types.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does this code do: template <typename T> T add(T a, T b) { return a + b; } int main() { cout << add(3, 4); return 0; }', options: ['Prints 7', 'Prints 34', 'Error', 'Nothing'], correctAnswer: 0),
  QuizQuestion(question: 'What is template specialization?', options: ['Writing a specific implementation for a particular type', 'Overloading a template', 'Deleting a template', 'Converting a template to a class'], correctAnswer: 0),
];

final List<QuizQuestion> stlQuiz = [
  QuizQuestion(question: 'What is the STL in C++?', options: ['A library of templates for common data structures and algorithms', 'A file handling system', 'A debugging tool', 'A networking library'], correctAnswer: 0),
  QuizQuestion(question: 'Which container stores elements in a dynamic array?', options: ['list', 'vector', 'set', 'map'], correctAnswer: 1),
  QuizQuestion(question: 'What does the push_back() function do in a vector?', options: ['Removes an element', 'Adds an element to the end', 'Adds an element to the front', 'Sorts the vector'], correctAnswer: 1),
  QuizQuestion(question: 'What is an iterator?', options: ['A pointer-like object used to traverse containers', 'A function in the STL', 'A type of template', 'A memory allocator'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: set automatically sorts its elements.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the sort() algorithm do?', options: ['Reverses a container', 'Sorts elements in ascending order by default', 'Removes duplicates', 'Finds an element'], correctAnswer: 1),
  QuizQuestion(question: 'What is the output of: vector<int> v = {3, 1, 4}; sort(v.begin(), v.end()); cout << v[1];', options: ['1', '3', '4', 'Error'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: map stores key-value pairs.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the find() algorithm return if the element is not found?', options: ['nullptr', 'end() iterator', '0', 'begin() iterator'], correctAnswer: 1),
  QuizQuestion(question: 'Which container allows duplicates?', options: ['set', 'map', 'vector', 'deque'], correctAnswer: 2),
];

final List<QuizQuestion> lambdaQuiz = [
  QuizQuestion(question: 'What is a lambda function?', options: ['A named function', 'An anonymous function defined inline', 'A recursive function', 'A virtual function'], correctAnswer: 1),
  QuizQuestion(question: 'What is the syntax of a basic lambda?', options: ['[capture](parameters) { body }', 'lambda(parameters) { body }', '(parameters) => { body }', '{ body }(parameters)'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Lambda functions can capture variables from their surrounding scope.', options: ['True', 'False'], correctAnswer: 0),
  // Continuing from lambdaQuiz
  QuizQuestion(question: 'What does this lambda do: auto add = [](int a, int b) { return a + b; }; cout << add(2, 3);', options: ['Prints 5', 'Prints 23', 'Error', 'Nothing'], correctAnswer: 0),
  QuizQuestion(question: 'What does [=] mean in a lambda?', options: ['Capture all variables by reference', 'Capture all variables by value', 'Capture nothing', 'Capture only pointers'], correctAnswer: 1),
];

final List<QuizQuestion> multithreadingQuiz = [
  QuizQuestion(question: 'What header is required for multithreading in C++?', options: ['<thread>', '<mutex>', '<vector>', '<iostream>'], correctAnswer: 0),
  QuizQuestion(question: 'What does the join() function do with a thread?', options: ['Starts the thread', 'Waits for the thread to finish', 'Detaches the thread', 'Pauses the thread'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: A mutex is used to prevent race conditions.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does this code do: #include <thread> void func() { cout << "Thread"; } int main() { thread t(func); t.join(); return 0; }', options: ['Prints "Thread"', 'Creates an infinite loop', 'Throws an error', 'Does nothing'], correctAnswer: 0),
  QuizQuestion(question: 'What is lock_guard used for?', options: ['To manually lock a thread', 'To automatically manage a mutex’s lock/unlock', 'To join threads', 'To detach threads'], correctAnswer: 1),
];

final List<QuizQuestion> smartPointersQuiz = [
  QuizQuestion(question: 'What is a smart pointer?', options: ['A pointer that manages memory automatically', 'A pointer that cannot be null', 'A pointer to a function', 'A pointer to a class'], correctAnswer: 0),
  QuizQuestion(question: 'Which smart pointer ensures exclusive ownership?', options: ['shared_ptr', 'unique_ptr', 'weak_ptr', 'auto_ptr'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: shared_ptr keeps a reference count to manage memory.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does weak_ptr help prevent?', options: ['Memory leaks', 'Dangling pointers', 'Circular references with shared_ptr', 'Null pointer exceptions'], correctAnswer: 2),
  QuizQuestion(question: 'What happens to a unique_ptr when it goes out of scope?', options: ['The memory is leaked', 'The memory is automatically deleted', 'The pointer is copied', 'Nothing happens'], correctAnswer: 1),
];

final List<QuizQuestion> networkingQuiz = [
  QuizQuestion(question: 'What is a socket in networking?', options: ['A type of pointer', 'An endpoint for communication between devices', 'A file handling object', 'A thread manager'], correctAnswer: 1),
  QuizQuestion(question: 'Which library is commonly used for sockets in C++?', options: ['<socket>', '<winsock2.h> (Windows) or <sys/socket.h> (Unix)', '<network>', '<iostream>'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: A client socket connects to a server socket.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the send() function do?', options: ['Receives data', 'Sends data over a socket', 'Closes a socket', 'Creates a socket'], correctAnswer: 1),
  QuizQuestion(question: 'What is the purpose of a server socket?', options: ['To send data only', 'To listen for incoming connections', 'To close connections', 'To allocate memory'], correctAnswer: 1),
];

final List<QuizQuestion> bestPracticesQuiz = [
  QuizQuestion(question: 'What is a good naming convention for variables?', options: ['x, y, z', 'descriptiveNamesLikeThis', 'VAR1, VAR2', 'a123, b456'], correctAnswer: 1),
  QuizQuestion(question: 'What should you avoid to prevent memory leaks?', options: ['Using new without delete', 'Using smart pointers', 'Using const', 'Using references'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Code optimization should always prioritize readability over performance.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What is a best practice for managing resources?', options: ['Manually delete all pointers', 'Use RAII (Resource Acquisition Is Initialization)', 'Avoid classes', 'Use global variables'], correctAnswer: 1),
  QuizQuestion(question: 'Why should you use consistent indentation?', options: ['To reduce memory usage', 'To improve code readability', 'To optimize performance', 'To prevent errors'], correctAnswer: 1),
];

final List<QuizQuestion> debuggingQuiz = [
  QuizQuestion(question: 'What is a common debugging technique?', options: ['Adding cout statements', 'Ignoring errors', 'Deleting code', 'Using throw everywhere'], correctAnswer: 0),
  QuizQuestion(question: 'What causes a segmentation fault?', options: ['Accessing invalid memory', 'Using too many variables', 'Forgetting a semicolon', 'Using cin'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Syntax errors are caught at runtime.', options: ['True', 'False'], correctAnswer: 1),
  QuizQuestion(question: 'What is the purpose of a debugger?', options: ['To write code', 'To step through code and inspect variables', 'To optimize performance', 'To handle files'], correctAnswer: 1),
  QuizQuestion(question: 'How can you fix an "undefined reference" error?', options: ['Define the missing function or variable', 'Delete the code', 'Use a different compiler', 'Ignore it'], correctAnswer: 0),
];

final List<QuizQuestion> advancedQuiz = [
  QuizQuestion(question: 'What is a function pointer?', options: ['A pointer to a variable', 'A pointer to a function', 'A pointer to a class', 'A smart pointer'], correctAnswer: 1),
  QuizQuestion(question: 'What does the typedef keyword do?', options: ['Creates a new data type', 'Defines an alias for an existing type', 'Declares a function', 'Allocates memory'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: The volatile keyword tells the compiler not to optimize a variable.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does the mutable keyword allow?', options: ['Modifying a variable in a const function', 'Creating a constant variable', 'Deleting a variable', 'Overriding a function'], correctAnswer: 0),
  QuizQuestion(question: 'What is the output of: void (*func)() = [](){ cout << "Lambda"; }; func();', options: ['Lambda', 'Error', 'Nothing', 'func'], correctAnswer: 0),
];

final List<QuizQuestion> todoListQuiz = [
  QuizQuestion(question: 'What OOP concept is used to represent a "Task" in a to-do list?', options: ['Inheritance', 'Class/Object', 'Polymorphism', 'Abstraction'], correctAnswer: 1),
  QuizQuestion(question: 'Why use file handling in a to-do list app?', options: ['To store tasks persistently', 'To optimize performance', 'To debug the app', 'To create threads'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Encapsulation can be used to hide task details.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What might a Task class include?', options: ['Private members like string name and public methods like getName()', 'Only public variables', 'A destructor that throws exceptions', 'A virtual function for file handling'], correctAnswer: 0),
  QuizQuestion(question: 'How would you save tasks to a file?', options: ['Using ofstream to write task data', 'Using cin to input tasks', 'Using vector alone', 'Using delete'], correctAnswer: 0),
];

final List<QuizQuestion> bankingQuiz = [
  QuizQuestion(question: 'What OOP concept allows a SavingsAccount to inherit from Account?', options: ['Inheritance', 'Encapsulation', 'Polymorphism', 'Abstraction'], correctAnswer: 0),
  QuizQuestion(question: 'How can polymorphism be used in a banking system?', options: ['To override a withdraw() method for different account types', 'To hide account details', 'To allocate memory', 'To read files'], correctAnswer: 0),
  QuizQuestion(question: 'True or False: Encapsulation can protect a user’s balance from direct modification.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What might a Bank class include?', options: ['A vector of Account objects', 'A single integer', 'A file pointer', 'A lambda function'], correctAnswer: 0),
  QuizQuestion(question: 'Why use inheritance in a banking system?', options: ['To reuse common account features across different account types', 'To optimize memory', 'To handle exceptions', 'To sort transactions'], correctAnswer: 0),
];

final List<QuizQuestion> finalQuiz = [
  QuizQuestion(question: 'What is the entry point of a C++ program?', options: ['start()', 'main()', 'run()', 'begin()'], correctAnswer: 1),
  QuizQuestion(question: 'What does cout << do?', options: ['Takes input', 'Outputs data', 'Declares a variable', 'Throws an exception'], correctAnswer: 1),
  QuizQuestion(question: 'What is the size of a char in bytes?', options: ['1', '2', '4', '8'], correctAnswer: 0),
  QuizQuestion(question: 'What does the virtual keyword enable?', options: ['Compile-time polymorphism', 'Runtime polymorphism', 'Memory allocation', 'File handling'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: A vector dynamically resizes as elements are added.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What is the purpose of a destructor?', options: ['To initialize an object', 'To clean up resources when an object is destroyed', 'To copy an object', 'To overload a function'], correctAnswer: 1),
  QuizQuestion(question: 'What does this code output: try { throw "Error"; } catch (const char* e) { cout << e; }', options: ['Error', 'Nothing', 'Exception', 'Crash'], correctAnswer: 0),
  QuizQuestion(question: 'What is the benefit of using unique_ptr?', options: ['Allows multiple owners', 'Prevents memory leaks with exclusive ownership', 'Enables circular references', 'Reduces performance'], correctAnswer: 1),
  QuizQuestion(question: 'True or False: Templates improve code reusability.', options: ['True', 'False'], correctAnswer: 0),
  QuizQuestion(question: 'What does STL stand for?', options: ['Standard Template Library', 'System Thread Library', 'Simple Type Language', 'Standard Type Loop'], correctAnswer: 0),
];

class ExerciseScreen extends StatelessWidget {
  const ExerciseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('C++ Exercises'),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: cppExercises.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: ListTile(
              title: Text(
                cppExercises[index].title,
                style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
              ),
              subtitle: Text(
                cppExercises[index].description,
                style: GoogleFonts.poppins(color: Colors.grey),
              ),
              trailing: const Icon(Icons.arrow_forward_ios, color: Color(0xFF6F35A5)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ExerciseDetailScreen(
                      title: cppExercises[index].title,
                      description: cppExercises[index].description,
                      expectedOutput: _getExpectedOutput(index),
                      starterCode: _getStarterCode(index),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  String _getExpectedOutput(int index) {
    // Add expected outputs for each exercise
    switch (index) {
      case 0:
        return 'Hello, World!';
      case 1:
        return 'Welcome to C++ Programming!';
      // Add more cases for other exercises
      default:
        return 'Expected output will be shown here';
    }
  }

  String _getStarterCode(int index) {
    // Add starter code for each exercise
    switch (index) {
      case 0:
        return '''#include <iostream>
using namespace std;

int main() {
    // Write your code here
    
    return 0;
}''';
      // Add more cases for other exercises
      default:
        return '''#include <iostream>
using namespace std;

int main() {
    // Write your solution here
    
    return 0;
}''';
    }
  }
}

class ExerciseDetailScreen extends StatelessWidget {
  final String title;
  final String description;
  final String expectedOutput;
  final String starterCode;

  const ExerciseDetailScreen({
    super.key,
    required this.title,
    required this.description,
    required this.expectedOutput,
    required this.starterCode,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              description,
              style: GoogleFonts.poppins(fontSize: 18, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            Text(
              'Expected Output:',
              style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              expectedOutput,
              style: GoogleFonts.poppins(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            Text(
              'Starter Code:',
              style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              starterCode,
              style: GoogleFonts.poppins(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class Exercise {
  final String title;
  final String description;

  const Exercise({required this.title, required this.description});
}

final List<Exercise> cppExercises = [
  // 1. Introduction to C++
  const Exercise(title: 'What is C++?', description: 'Write a short paragraph explaining what C++ is and why it’s used in programming.'),
  const Exercise(title: 'Key Features of C++', description: 'List five key features of C++ and briefly describe each in your own words.'),
  const Exercise(title: 'Install a C++ Compiler', description: 'Install a C++ compiler (e.g., GCC or Clang) on your system and document the steps for your OS (Windows, Mac, or Linux).'),
  const Exercise(title: 'Welcome Program', description: 'Write a C++ program that prints "Welcome to C++ Programming!" to the console and compile/run it.'),
  const Exercise(title: 'Personalized Welcome', description: 'Modify the program from the previous exercise to also print your name on a new line.'),

  // 2. C++ Syntax & Structure
  const Exercise(title: 'Structured Hello World', description: 'Write a C++ program with proper structure (including #include, namespace, and main()) that outputs "Hello, World!".'),
  const Exercise(title: 'Input Echo', description: 'Create a program that uses cout to display "Enter a number: ", takes an integer input using cin, and prints it back.'),
  const Exercise(title: 'Commented Program', description: 'Add single-line and multi-line comments to the "Structured Hello World" program explaining what each line does.'),
  const Exercise(title: 'Using std:: Prefix', description: 'Write a program that demonstrates the use of std:: prefix instead of "using namespace std;" for cout and cin.'),

  // 3. Variables & Data Types
  const Exercise(title: 'Variable Declarations', description: 'Declare variables of types int, float, double, char, and bool, assign them values, and print them using cout.'),
  const Exercise(title: 'Circle Area Calculator', description: 'Write a program that defines a constant PI using both const and #define, then calculates and prints the area of a circle for a user-input radius.'),
  const Exercise(title: 'Implicit Conversion', description: 'Create a program that demonstrates implicit type conversion by adding an int and a float, then printing the result.'),
  const Exercise(title: 'Explicit Conversion', description: 'Write a program that uses static_cast to convert a double to an int and displays both values.'),

  // 4. Operators in C++
  const Exercise(title: 'Arithmetic Operations', description: 'Write a program that takes two integers as input and performs all arithmetic operations (+, -, *, /, %) on them, displaying the results.'),
  const Exercise(title: 'Relational Comparison', description: 'Create a program that uses relational operators to compare two user-input numbers and prints whether they are equal, greater, or less than each other.'),
  const Exercise(title: 'Logical Check', description: 'Write a program that uses logical operators to check if a number is both positive and even, then prints the result.'),
  const Exercise(title: 'Ternary Even/Odd', description: 'Demonstrate the ternary operator by writing a program that takes an integer input and prints "Even" or "Odd" based on its value.'),

  // 5. Control Flow
  const Exercise(title: 'Number Sign Check', description: 'Write a program that takes an integer input and uses if-else to determine if it’s positive, negative, or zero.'),
  const Exercise(title: 'Age Categorizer', description: 'Create a program that takes a user’s age and uses else-if to categorize them as "Child" (0-12), "Teen" (13-19), or "Adult" (20+).'),
  const Exercise(title: 'Day Switch', description: 'Write a program that takes a character input (a-e) and uses switch-case to print the corresponding day of the week (e.g., a = Monday).'),
  const Exercise(title: 'For Loop 1-10', description: 'Write a program that uses a for loop to print numbers from 1 to 10.'),
  const Exercise(title: 'While Even Numbers', description: 'Create a program that uses a while loop to print the first 5 even numbers starting from 2.'),
  const Exercise(title: 'Do-While Positive', description: 'Write a program that uses a do-while loop to keep asking for a positive number until the user enters one, then prints it.'),

  // 6. Functions in C++
  const Exercise(title: 'Addition Function', description: 'Write a function "add" that takes two integers as arguments and returns their sum, then call it in main() with user input.'),
  const Exercise(title: 'Greeting Function', description: 'Create a function "greet" with a default argument for a name ("Guest") that prints a greeting, and test it with and without an argument.'),
  const Exercise(title: 'Max Overload', description: 'Overload a function "max" to find the maximum of two integers and two doubles, then test both versions.'),
  const Exercise(title: 'Factorial Recursion', description: 'Write a recursive function to calculate the factorial of a number and test it with input 5.'),

  // 7. Arrays in C++
  const Exercise(title: '1D Array Input', description: 'Write a program that declares a one-dimensional array of 5 integers, initializes it with user input, and prints all elements.'),
  const Exercise(title: '2D Array Grid', description: 'Create a program that declares a 2D array (3x3), fills it with numbers 1-9, and prints it as a grid.'),
  const Exercise(title: 'Array Sum', description: 'Write a program that finds the sum of all elements in a user-input array of size 5.'),
  const Exercise(title: 'Array Reverse', description: 'Create a program that reverses a one-dimensional array of 5 integers and prints the result.'),

  // 8. Strings in C++
  const Exercise(title: 'String Length', description: 'Write a program that declares a string variable, takes a user-input string, and prints its length using length().'),
  const Exercise(title: 'Substring Extract', description: 'Create a program that uses substr() to extract the first 3 characters of a user-input string and prints them.'),
  const Exercise(title: 'String Append', description: 'Write a program that appends " World" to the string "Hello" using append() and prints the result.'),
  const Exercise(title: 'String Comparison', description: 'Compare two user-input strings using == and print whether they are equal or not.'),

  // 9. Pointers in C++
  const Exercise(title: 'Pointer Basics', description: 'Write a program that declares an integer, a pointer to it, and prints both the value and address using the pointer.'),
  const Exercise(title: 'Pointer Arithmetic', description: 'Create a program that uses pointer arithmetic to increment a pointer to an integer array and prints the next element.'),
  const Exercise(title: 'NULL vs nullptr', description: 'Write a program that demonstrates the difference between NULL and nullptr by assigning them to pointers and checking their values.'),
  const Exercise(title: 'Array Traversal', description: 'Create a program that uses a pointer to traverse and print all elements of a 5-element integer array.'),

  // 10. Dynamic Memory Allocation
  const Exercise(title: 'Single Integer Allocation', description: 'Write a program that uses new to allocate memory for an integer, assigns a value, prints it, and deallocates it with delete.'),
  const Exercise(title: 'Dynamic Array', description: 'Create a program that dynamically allocates an array of 5 integers using new, fills it with user input, and prints it before deallocating.'),
  const Exercise(title: 'Malloc Usage', description: 'Write a program that uses malloc() to allocate memory for 5 integers, assigns values, prints them, and frees the memory with free().'),

  // 11. References in C++
  const Exercise(title: 'Reference Modification', description: 'Write a program that declares an integer and a reference to it, modifies the reference, and prints the original variable.'),
  const Exercise(title: 'Swap Function', description: 'Create a function "swap" that takes two integers by reference and swaps their values, then test it in main().'),
  const Exercise(title: 'Pointer vs Reference', description: 'Write a program that compares the syntax and behavior of a pointer vs. a reference to the same variable.'),

  // 12. Object-Oriented Programming (OOP) in C++
  const Exercise(title: 'Car Class', description: 'Define a Car class with attributes speed and color, create an object, and print its details.'),
  const Exercise(title: 'Encapsulated Car', description: 'Write a program that demonstrates encapsulation by making Car attributes private and adding public methods to access them.'),
  const Exercise(title: 'Rectangle Class', description: 'Create a Rectangle class with methods to calculate area and perimeter, then test it with an object.'),

  // 13. Constructors & Destructors
  const Exercise(title: 'Default Constructor', description: 'Write a Book class with a default constructor that initializes title to "Unknown" and prints a message, then test it.'),
  const Exercise(title: 'Parameterized Constructor', description: 'Add a parameterized constructor to the Book class that takes a title and page count, then create an object with it.'),
  const Exercise(title: 'Destructor', description: 'Add a destructor to the Book class that prints "Book destroyed" and test it by creating and destroying an object.'),

  // 14. Inheritance in C++
  const Exercise(title: 'Vehicle Inheritance', description: 'Create a Vehicle base class with a speed attribute and a Car derived class that adds a model attribute, then test it.'),
  const Exercise(title: 'Multilevel Inheritance', description: 'Write a program that demonstrates multilevel inheritance: Animal → Mammal → Dog, each adding one attribute.'),
  const Exercise(title: 'Multiple Inheritance', description: 'Create a program with multiple inheritance where a HybridCar inherits from both Car and ElectricVehicle.'),

  // 15. Polymorphism in C++
  const Exercise(title: 'Function Overloading', description: 'Overload a print function to handle an integer and a string, then test both versions.'),
  const Exercise(title: 'Virtual Method', description: 'Write a program with a Shape base class and Circle derived class, using a virtual area() method overridden in Circle.'),
  const Exercise(title: 'Operator Overloading', description: 'Create a program that overloads the + operator for a Point class to add two points’ coordinates.'),

  // 16. Encapsulation & Abstraction
  const Exercise(title: 'Student Class', description: 'Write a Student class with private attributes name and grade, and public getters/setters to access them.'),
  const Exercise(title: 'Letter Grade', description: 'Modify the Student class to include a method that calculates a letter grade (A, B, C, etc.) based on a private score.'),
  const Exercise(title: 'Abstract Shape', description: 'Create an abstract Shape class with a pure virtual draw() method, implemented by a Triangle class.'),

  // 17. Exception Handling in C++
  const Exercise(title: 'Division by Zero', description: 'Write a program that uses try and catch to handle a division-by-zero error when dividing two user-input numbers.'),
  const Exercise(title: 'Negative Number Exception', description: 'Create a program that throws an exception if a user enters a negative number and catches it with a custom message.'),
  const Exercise(title: 'Multiple Catches', description: 'Write a program with multiple catch blocks to handle both int and string exceptions.'),

  // 18. File Handling in C++
  const Exercise(title: 'Write to File', description: 'Write a program that uses ofstream to write "Hello, File!" to a file named "output.txt".'),
  const Exercise(title: 'Read from File', description: 'Create a program that reads a line from "input.txt" using ifstream and prints it to the console.'),
  const Exercise(title: 'Append to File', description: 'Write a program that appends a user-input string to "data.txt" using ios::app mode.'),

  // 19. Templates in C++
  const Exercise(title: 'Max Template', description: 'Write a function template "maxValue" that returns the maximum of two values (test with int and double).'),
  const Exercise(title: 'Pair Template', description: 'Create a Pair class template with two data members of any type and a method to print them.'),
  const Exercise(title: 'Specialized Pair', description: 'Specialize the Pair class template for string to concatenate the two strings when printing.'),

  // 20. Standard Template Library (STL)
  const Exercise(title: 'Vector Basics', description: 'Write a program that creates a vector of 5 integers, adds elements with push_back(), and prints them.'),
  const Exercise(title: 'Set Sorting', description: 'Create a program that uses a set to store 5 user-input numbers and prints them in sorted order.'),
  const Exercise(title: 'Vector Sort', description: 'Write a program that uses sort() to sort a vector of strings and prints the result.'),

  // 21. Lambda Functions in C++
  const Exercise(title: 'Lambda Sum', description: 'Write a lambda function that takes two integers and returns their sum, then test it.'),
  const Exercise(title: 'Capture Lambda', description: 'Create a program that uses a lambda with [=] capture to add a captured variable to a user-input number.'),
  const Exercise(title: 'Lambda with std::function', description: 'Write a lambda function with std::function to multiply two numbers and call it in main().'),

  // 22. Multithreading in C++
  const Exercise(title: 'Basic Thread', description: 'Write a program that creates a thread to print "Hello from thread!" and joins it in main().'),
  const Exercise(title: 'Concurrent Threads', description: 'Create a program with two threads that print numbers 1-5 and 6-10 concurrently.'),
  const Exercise(title: 'Mutex Counter', description: 'Write a program that uses a mutex to safely increment a shared counter from two threads.'),

  // 23. Smart Pointers in C++
  const Exercise(title: 'Unique Pointer', description: 'Write a program that uses a unique_ptr to manage an integer, assigns a value, and prints it.'),
  const Exercise(title: 'Shared Pointer', description: 'Create a program that uses a shared_ptr to manage a string, shared between two variables, and prints its value.'),
  const Exercise(title: 'Weak Pointer', description: 'Write a program that demonstrates a weak_ptr resolving a circular reference between two classes.'),

  // 24. Networking in C++
  const Exercise(title: 'Simple Server', description: 'Write a simple server program using sockets that listens for a connection and prints a received message.'),
  const Exercise(title: 'Simple Client', description: 'Create a client program that connects to the server and sends "Hello, Server!".'),
  const Exercise(title: 'Echo Server', description: 'Modify the server to echo back the client’s message after receiving it.'),

  // 25. C++ Best Practices
  const Exercise(title: 'Readable Code', description: 'Rewrite a poorly named program (e.g., int x; int y; x = 5; y = 10; cout << x + y;) with meaningful variable names and comments.'),
  const Exercise(title: 'Optimization', description: 'Optimize a program that calculates the sum of an array by reducing redundant loops or operations.'),
  const Exercise(title: 'RAII Practice', description: 'Write a program following RAII principles to manage a dynamically allocated resource.'),

  // 26. C++ Debugging & Error Handling
  const Exercise(title: 'Fix Pointer Error', description: 'Debug this code by fixing the error and explaining it: int* ptr; *ptr = 5; cout << *ptr;'),
  const Exercise(title: 'Array Bounds Error', description: 'Write a program with an array out-of-bounds error and explain how to fix it using a debugger.'),
  const Exercise(title: 'Runtime Recovery', description: 'Create a program that causes a runtime error and adds error handling to recover gracefully.'),

  // 27. Advanced C++ Concepts
  const Exercise(title: 'Function Pointer', description: 'Write a program that uses a function pointer to call a function that doubles an integer.'),
  const Exercise(title: 'Typedef Alias', description: 'Use typedef to create an alias for std::vector<int> and test it in a program.'),
  const Exercise(title: 'Mutable Member', description: 'Write a program that uses mutable in a const member function to modify a class member.'),

  // 28. C++ Project: To-Do List Application
  const Exercise(title: 'Task Class', description: 'Create a Task class with attributes title and completed, and methods to mark it complete.'),
  const Exercise(title: 'Task Storage', description: 'Write a program that stores a list of Task objects in a vector and saves them to a file.'),
  const Exercise(title: 'Task Retrieval', description: 'Add functionality to read tasks from the file and display them with their completion status.'),

  // 29. C++ Project: Banking System
  const Exercise(title: 'Account Hierarchy', description: 'Define an Account base class with balance and methods for deposit/withdrawal, and a SavingsAccount derived class with interest.'),
  const Exercise(title: 'Banking Encapsulation', description: 'Implement encapsulation by making balance private and adding getters/setters.'),
  const Exercise(title: 'Banking Polymorphism', description: 'Add polymorphism by overriding a display() method in SavingsAccount to show interest details.'),

  // 30. Final Quiz & Certification
  const Exercise(title: 'Expense Tracker', description: 'Write a complete C++ program that integrates variables, loops, functions, and file handling to track daily expenses.'),
  const Exercise(title: 'Library Mini-Project', description: 'Create a mini-project that uses OOP (e.g., a Library class with Book objects) and demonstrates inheritance and polymorphism.'),
  const Exercise(title: 'Code Optimization', description: 'Debug and optimize a provided program (e.g., one with redundant loops or memory leaks) and explain your changes.'),
];

class ResourcesScreen extends StatelessWidget {
  const ResourcesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Resources'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildResourceCard(
            context,
            'C++ Documentation',
            'Official C++ reference and documentation',
            Icons.book,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DocumentationScreen()),
            ),
          ),
          _buildResourceCard(
            context,
            'Video Tutorials',
            'Learn C++ through video lessons',
            Icons.video_library,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const VideoTutorialsScreen()),
            ),
          ),
          _buildResourceCard(
            context,
            'Code Examples',
            'Explore practical C++ code snippets',
            Icons.code,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const CodeExamplesScreen()),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResourceCard(BuildContext context, String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        leading: Icon(icon, size: 40, color: const Color(0xFF9575CD)), // Violet accent
        title: Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white)), // White for dark theme
        subtitle: Text(subtitle, style: GoogleFonts.poppins(color: Colors.grey)), // Grey for contrast
        trailing: const Icon(Icons.arrow_forward_ios, color: Color(0xFF6F35A5)), // Violet arrow
        onTap: onTap,
      ),
    );
  }
}

class DocumentationScreen extends StatelessWidget {
  const DocumentationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('C++ Documentation'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            const url = 'https://en.cppreference.com/w/';
            if (await canLaunchUrl(Uri.parse(url))) {
              await launchUrl(Uri.parse(url));
            }
          },
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6F35A5)), // Violet button
          child: const Text('Visit cppreference.com'),
        ),
      ),
    );
  }
}

class VideoTutorialsScreen extends StatelessWidget {
  const VideoTutorialsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Tutorials'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildVideoCard(
            context,
            'C++ Basics',
            'Learn the fundamentals of C++',
            'https://www.youtube.com/watch?v=vLnPwxZdW4Y',
          ),
          _buildVideoCard(
            context,
            'OOP in C++',
            'Understand Object-Oriented Programming',
            'https://www.youtube.com/watch?v=wN0xCwGcDA8',
          ),
        ],
      ),
    );
  }

  Widget _buildVideoCard(BuildContext context, String title, String description, String url) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        title: Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white)), // White for dark theme
        subtitle: Text(description, style: GoogleFonts.poppins(color: Colors.grey)), // Grey for contrast
        trailing: const Icon(Icons.play_arrow, color: Color(0xFF6F35A5)), // Violet play icon
        onTap: () async {
          if (await canLaunchUrl(Uri.parse(url))) {
            await launchUrl(Uri.parse(url));
          }
        },
      ),
    );
  }
}

class CodeExamplesScreen extends StatelessWidget {
  const CodeExamplesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Code Examples'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildCodeCard(
            'Hello World',
            '#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << "Hello, World!";\n    return 0;\n}',
          ),
          _buildCodeCard(
            'Simple Class',
            '#include <iostream>\nusing namespace std;\n\nclass MyClass {\npublic:\n    int x;\n    void display() {\n        cout << "Value: " << x;\n    }\n};\n\nint main() {\n    MyClass obj;\n    obj.x = 10;\n    obj.display();\n    return 0;\n}',
          ),
        ],
      ),
    );
  }

  Widget _buildCodeCard(String title, String code) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)), // White for dark theme
            const SizedBox(height: 8),
            Text(code, style: GoogleFonts.poppins(color: Colors.grey, fontSize: 14)), // Grey for contrast
          ],
        ),
      ),
    );
  }
}