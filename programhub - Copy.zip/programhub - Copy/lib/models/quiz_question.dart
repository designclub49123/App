class QuizQuestion {
  final String question;
  final List<String> options;
  final int correctAnswer;
  final String explanation;
  final String correctFeedback;
  final String incorrectFeedback;

  const QuizQuestion({
    required this.question,
    required this.options,
    required this.correctAnswer,
    this.explanation = '',
    this.correctFeedback = 'Correct!',
    this.incorrectFeedback = 'Try again.',
  });
}
